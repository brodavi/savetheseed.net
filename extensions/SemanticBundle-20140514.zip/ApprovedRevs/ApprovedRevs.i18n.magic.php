<?php
/**
 *  Magic words for extension.
 */

$magicWords = array();

/** English (English) */
$magicWords['en'] = array(
	'MAG_APPROVEDREVS' => array( 0, '__APPROVEDREVS__' ),
);
